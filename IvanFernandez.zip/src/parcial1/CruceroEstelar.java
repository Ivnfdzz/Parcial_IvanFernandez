package parcial1;

import java.util.Objects;

public class CruceroEstelar extends Nave{
    private int cantidadPasajeros;

    public CruceroEstelar(int cantidadPasajeros, String nombre, int cantidadTripulacion, int añoLanzamiento) {
        super(nombre, cantidadTripulacion, añoLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    
    @Override
    public String toString() {
        return "CruceroEstelar{" + "nombre=" + getNombre() + ", cantidadTripulacion=" + getCantidadTripulacion() +
                ", anioLanzamiento=" + getAnioLanzamiento() + "cantidadPasajeros=" + cantidadPasajeros + '}';
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(getNombre(), getAnioLanzamiento());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Nave other = (Nave) obj;
        if (this.getAnioLanzamiento() != other.getAnioLanzamiento()) {
            return false;
        }
        return Objects.equals(this.getNombre(), other.getNombre());
    }


}
