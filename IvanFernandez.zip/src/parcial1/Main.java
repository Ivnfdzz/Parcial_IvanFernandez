package parcial1;

public class Main {

    public static void main(String[] args) {

        Agencia agencia = new Agencia();
        
        try {
            agencia.agregarNave(new Carguero(300, "Galactica", 400, 2060));
            //agencia.agregarNave(new Carguero(490, "Galactica", 450, 2060));
            agencia.agregarNave(new CruceroEstelar(400, "CruceroSpaceX", 937, 2032));
            agencia.agregarNave(new NaveExploracion(TipoMision.CONTACTO, "Explorer2000", 320, 2037));
            agencia.agregarNave(new Carguero(30, "Elon", 423, 2040));
            agencia.mostrarNaves();
            agencia.iniciarExploracion();
        } catch (CapacidadCargueroInvalidaException e) {
            System.out.println("Error de capacidad: " + e.getMessage());
        } catch (NaveRepetidaException e) {
            System.out.println("Error de nave repetida: " + e.getMessage());
        } catch (IllegalArgumentException | NullPointerException e) {
            System.out.println(e.getMessage());
        }
   
        
        
        
        
         
    }   
}