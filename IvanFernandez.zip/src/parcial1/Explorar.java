package parcial1;

public interface Explorar {
    public void explorar();
}
