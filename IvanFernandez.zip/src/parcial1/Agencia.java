package parcial1;

import java.util.ArrayList;
import java.util.List;

public class Agencia {
    private List<Nave> naves;

    public Agencia() {
        this.naves = new ArrayList<>();
    }
    
    public void agregarNave(Nave n){
        if(checkNaveRepetida(n)){
           throw new  NaveRepetidaException();
        } else{
            this.naves.add(n);
        }
    }
    
    private boolean checkNaveRepetida(Nave n){
        boolean repeticion = false;
        for (Nave nave : naves) {
            if(nave.equals(n)){
                repeticion = true;
            } else{
                repeticion = false;
            }
        } return repeticion;
    }
    
    public void mostrarNaves(){
        if (naves.isEmpty()){
            System.out.println("No hay naves");
        } else{
            for (Nave n : naves) {
                System.out.println(n);
            }
        }
    }
    
    public void iniciarExploracion(){
        for (Nave n : naves){
            if (n instanceof Explorar naveExploradora){
                naveExploradora.explorar();
            } else {
                System.out.println("La nave " + n.getNombre() + " NO puede explorar dado a que es un Curcero Estelar");
            }
        }
    }
    
    

}