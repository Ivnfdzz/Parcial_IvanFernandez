package parcial1;

public class NaveRepetidaException extends IllegalArgumentException {
    
    private final static String MESSAGE = "La nave que quieres añadir ya existe dentro de nuestra agencia";
    
    public NaveRepetidaException(){
        super(MESSAGE);
    }
}