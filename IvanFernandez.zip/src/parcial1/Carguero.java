package parcial1;

import java.util.Objects;

public class Carguero extends Nave implements Explorar{
    private int capacidadCarga;
    private static final int MAX_CARGA = 500;
    private static final int MIN_CARGA = 100;

    public Carguero(int capacidadCarga, String nombre, int cantidadTripulacion, int añoLanzamiento) {
    super(nombre, cantidadTripulacion, añoLanzamiento);
    if (validarCarga(capacidadCarga)) {
        this.capacidadCarga = capacidadCarga;
    } else {
        throw new CapacidadCargueroInvalidaException();
    }
}

private boolean validarCarga(int capacidad) {
    return capacidad > MIN_CARGA && capacidad < MAX_CARGA;
}

    
    @Override
    public String toString() {
        return "Carguero{" + "nombre=" + getNombre() + ", cantidadTripulacion=" + getCantidadTripulacion() +
                ", anioLanzamiento=" + getAnioLanzamiento() + "capacidadCarga=" + capacidadCarga + '}';
    }
    
    @Override
    public void explorar() {
        System.out.println("La nave " + getNombre() + " esta comenzando una exploracion...");
    }
    
    
    @Override
    public int hashCode() {
        return Objects.hash(getNombre(), getAnioLanzamiento());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Nave other = (Nave) obj;
        if (this.getAnioLanzamiento() != other.getAnioLanzamiento()) {
            return false;
        }
        return Objects.equals(this.getNombre(), other.getNombre());
    }
 
}
