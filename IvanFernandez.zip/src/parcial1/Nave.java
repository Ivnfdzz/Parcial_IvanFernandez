package parcial1;

import java.util.Objects;

public abstract class Nave {
    private String nombre;
    private int cantidadTripulacion;
    private int anioLanzamiento;

    public Nave(String nombre, int cantidadTripulacion, int añoLanzamiento) {
        this.nombre = nombre;
        this.cantidadTripulacion = cantidadTripulacion;
        this.anioLanzamiento = añoLanzamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidadTripulacion() {
        return cantidadTripulacion;
    }

    public int getAnioLanzamiento() {
        return anioLanzamiento;
    }

    @Override
    public String toString() {
        return "Nave{" + "nombre=" + nombre + ", cantidadTripulacion=" + cantidadTripulacion + ", a\u00f1oLanzamiento=" + anioLanzamiento + '}';
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(nombre, anioLanzamiento);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Nave other = (Nave) obj;
        if (this.anioLanzamiento != other.anioLanzamiento) {
            return false;
        }
        return Objects.equals(this.nombre, other.nombre);
    }
    
    
}
