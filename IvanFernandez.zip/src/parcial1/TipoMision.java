package parcial1;

public enum TipoMision {
    CARTOGRAFIA, INVESTIGACION, CONTACTO
}
