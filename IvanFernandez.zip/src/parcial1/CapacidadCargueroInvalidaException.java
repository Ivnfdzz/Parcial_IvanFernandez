package parcial1;

public class CapacidadCargueroInvalidaException extends IllegalArgumentException {
    
    private final static String MESSAGE = "La carga que puede llevar el carguero va desde 100 a 500 toneladas";
    
    public CapacidadCargueroInvalidaException(){
        super(MESSAGE);
    }
}
